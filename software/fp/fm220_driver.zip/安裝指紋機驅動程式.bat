@echo off
pnputil -a "Fm220WinUSB.inf"
if %errorlevel% == 0 goto success
echo NOT INSTALLED!
goto end
:success
echo Installation completed.
echo You can use the device now.
:end
pause